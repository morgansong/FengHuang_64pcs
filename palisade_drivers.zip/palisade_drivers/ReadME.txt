1. get the individual drivers running direct from the .py file. Start with the cubic_CB-HCHO.py (includes more useful comments)
2. Generate .exe with the generate_palisade_EXEs.py

Limited support by ueli.schoen@sensirion.com